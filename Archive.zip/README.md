---
author: Simnon J. Kiss, Wilfrid Laurier University 
date: 
title: Politics in Waterloo Region
---

# Politics in Waterloo Region

This is the GitHub Repository for the Laurier Institute for the Study of Public Opinion and Policy's 2021 survey of political attitudes in the spring of 2021. 

## This is a Markdown document 
Markdown is an extremely easy markup language that allows people to focus on what they write, rather than how they format it. You can italicize words like this with *asterisks*. Or you can **bold**. You can also include lengthy block quotes:
> This is some very interesting things I have to say about that. 

A table can be made quite easily and quickly as well. 

| Header 1 | Header 2 | Header 3 | 
| ----------|-------| ---|
| Cell 1 text | Cell 2 Text | Cell 3 Text| 
