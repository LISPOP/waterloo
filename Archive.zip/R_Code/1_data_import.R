#load libraries
library(tidyverse)
library(labelled)
library(haven)
library(here)

#Load data with haven
waterloo<-read_sav(here("data/WRMS2021_autotest.sav"))

#Genreate fake weight data
waterloo$weight<-rnorm(1.5, sd=0.25, n=nrow(waterloo))

#install.packages(c('survey', 'srvyr'))
library(srvyr)
library(survey)
#Makd a survey dseign object using the weight variable
#The final data-set will have a variable like this.
waterloo %>% 
  as_survey_design(., weights=weight) ->waterloo2

#Make a table of frequencies for a variable using the svytable command in the survey package
#This is the old school way
survey::svytable(~K1, design=waterloo2)

#Find another variable to crosstab with
library(labelled)
#This is a very useful keyword search function for labelled datga
look_for(waterloo, "employment")

#crosstab in the original survey package
survey::svytable(~as_factor(H1)+as_factor(K1), design=waterloo2)
#In the tidy way srvyr which calls the survey package; does not have an equivalent function to svytable
waterloo2 %>% 
  group_by(H1, K1) %>% 
  summarize(n=survey_total()) %>% 
  as_factor() %>% 
  select(-n_se) %>% 
 pivot_wider(names_from=c(K1), values_from=c(n))

#This can be fed right to ggplot
waterloo2 %>% 
  group_by(H1, K1) %>% 
  summarize(n=survey_total()) %>% 
  as_factor() %>% 
  select(-n_se) %>% 
  #Can feed this right to databale for a searchable table. 
  pivot_wider(names_from=c(K1), values_from=c(n)) %>% 
  DT::datatable()

#Or go right to ggplot
waterloo2 %>% 
  group_by(H1, K1) %>% 
  summarize(n=survey_total()) %>% 
  as_factor() %>% 
  select(-n_se) %>% 
  ggplot(., aes(x=H1, y=n, fill=K1))+geom_col(position='dodge')
#The Base R way
table(as_factor(waterloo$H1), as_factor(waterloo$K1))

